package AirportPackage.AirlinePackage;
/**
 * Backbone of airline personnel .
 * In case of needed  other personnel type can be derived.
 * @author Nevzat Seferoglu
 * @version 1.0
 */
public class AirlinePersonnel { }