package AirportPackage.AirlinePackage;
/**
 * Destination properties class which is designed
 * according to perspective of current airport.
 * @author Nevzat Seferoglu
 * @version 1.0
 */
public class Destination {
    /* Identifier of airport will be handled */
}