package AirportPackage;

class AirPortSystem{
    public static void main(String args[]) {
        CompanyManager test = new CompanyManager();
        test.login();
        System.out.println("Hello Java");
    }
}